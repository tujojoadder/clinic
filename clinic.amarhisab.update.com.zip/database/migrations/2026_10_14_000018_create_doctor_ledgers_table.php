<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('doctor_ledgers', function (Blueprint $table) {
            $table->id('id');
            $table->unsignedBigInteger('doctor_id');
            $table->enum('type', [
    'payable',
    'settlement',
]);
            $table->decimal('amount', 12, 2);
            $table->date('entry_date');
            $table->string('notes', 255);
            $table->dateTime('created_at')->useCurrent();
            $table->foreign('doctor_id')->references('id')->on('doctors');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('doctor_ledgers');
    }
};
