<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id('id');
            $table->unsignedBigInteger('patient_id');
            $table->unsignedBigInteger('visit_id')->nullable()->unique();
            $table->unsignedBigInteger('admission_id')->nullable()->unique();
            $table->decimal('discount', 12, 2)->default(0);
            $table->enum('status', [
    'open',
    'finalized',
    'void',
])->default('open');
            $table->text('notes')->nullable();
            $table->dateTime('created_at')->useCurrent();
            $table->foreign('patient_id')->references('id')->on('patients');
            $table->foreign('visit_id')->references('id')->on('visits');
            $table->foreign('admission_id')->references('id')->on('admissions');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoices');
    }
};
