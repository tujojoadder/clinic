<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('bed_stays', function (Blueprint $table) {
            $table->id('id');
            $table->unsignedBigInteger('admission_id');
            $table->unsignedBigInteger('bed_id');
            $table->dateTime('started_at');
            $table->dateTime('ended_at')->nullable();
            $table->decimal('daily_rate', 12, 2);
            $table->foreign('admission_id')->references('id')->on('admissions');
            $table->foreign('bed_id')->references('id')->on('beds');
            $table->index([
    'bed_id',
    'ended_at',
]);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bed_stays');
    }
};
