<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('lab_orders', function (Blueprint $table) {
            $table->id('id');
            $table->unsignedBigInteger('patient_id');
            $table->unsignedBigInteger('admission_id')->nullable();
            $table->unsignedBigInteger('invoice_id');
            $table->unsignedBigInteger('test_id');
            $table->enum('status', [
    'ordered',
    'collected',
    'processing',
    'review',
    'approved',
    'cancelled',
])->default('ordered');
            $table->dateTime('ordered_at');
            $table->dateTime('collected_at')->nullable();
            $table->dateTime('approved_at')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->text('report_notes')->nullable();
            $table->foreign('patient_id')->references('id')->on('patients');
            $table->foreign('admission_id')->references('id')->on('admissions');
            $table->foreign('invoice_id')->references('id')->on('invoices');
            $table->foreign('test_id')->references('id')->on('tests');
            $table->foreign('approved_by')->references('id')->on('users');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lab_orders');
    }
};
