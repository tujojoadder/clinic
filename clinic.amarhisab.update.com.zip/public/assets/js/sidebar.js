/* public/assets/sidebar.js - সাইডবারের স্ক্রল পজিশন মনে রাখে */
(function () {
    var KEY = "clinicSidebarScroll";
    var aside =
        document.getElementById("sideBar") || document.querySelector("aside");
    if (!aside) return;

    // aside এবং তার ভেতরের যেসব এলিমেন্টে স্ক্রল হতে পারে সেগুলো খুঁজে বের করা
    function scrollers() {
        var list = [aside].concat([].slice.call(aside.querySelectorAll("*")));
        return list.filter(function (el) {
            var o = getComputedStyle(el).overflowY;
            return o === "auto" || o === "scroll" || o === "overlay";
        });
    }

    function save() {
        try {
            var data = scrollers().map(function (el) {
                return el.scrollTop;
            });
            sessionStorage.setItem(KEY, JSON.stringify(data));
        } catch (e) {}
    }

    function restore() {
        var data = null;
        try {
            data = JSON.parse(sessionStorage.getItem(KEY));
        } catch (e) {}
        if (!data) return false;
        var list = scrollers();
        list.forEach(function (el, i) {
            if (data[i] != null) el.scrollTop = data[i];
        });
        return true;
    }

    // সেভ করা পজিশন না থাকলে সক্রিয় মেনুটি মাঝামাঝি দেখানো
    function showActive() {
        var link = aside.querySelector("a.primary");
        if (!link) return;
        scrollers().forEach(function (sc) {
            if (sc.scrollHeight > sc.clientHeight + 1) {
                var l = link.getBoundingClientRect();
                var s = sc.getBoundingClientRect();
                sc.scrollTop +=
                    l.top - s.top - sc.clientHeight / 2 + l.height / 2;
            }
        });
    }

    // স্মুথ স্ক্রল থাকলে পজিশন বসানোর সময় সাময়িকভাবে বন্ধ রাখা
    function instant(fn) {
        var els = scrollers();
        var old = els.map(function (el) {
            return el.style.scrollBehavior;
        });
        els.forEach(function (el) {
            el.style.scrollBehavior = "auto";
        });
        fn();
        els.forEach(function (el, i) {
            el.style.scrollBehavior = old[i];
        });
    }

    var hadSaved = false;
    function apply() {
        instant(function () {
            var ok = restore();
            if (ok) hadSaved = true;
            else showActive();
        });
    }

    apply();
    document.addEventListener("DOMContentLoaded", apply);
    window.addEventListener("load", apply);
    setTimeout(apply, 150);

    var t;
    function later() {
        clearTimeout(t);
        t = setTimeout(save, 60);
    }
    scrollers().forEach(function (el) {
        el.addEventListener("scroll", later, { passive: true });
    });
    aside.addEventListener("click", save);
    window.addEventListener("pagehide", save);
})();
