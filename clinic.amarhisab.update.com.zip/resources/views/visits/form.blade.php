@extends('layouts.app', ['title' => 'ডাক্তার ও সিরিয়াল'])
@section('content')
    <section class="panel">
        <div class="panelhead">
            <h2>{{ $record->exists ? 'তথ্য সম্পাদনা' : 'নতুন এন্ট্রি' }}</h2>
        </div>
        <div class="panelbody">
            <form method="post" action="{{ $record->exists ? route('visits.update', $record) : route('visits.store') }}">
                @csrf
                @if ($record->exists)
                    @method('PUT')
                @endif
                <div class="formgrid">
                    <div>
                        <label for="patient_id">রোগী *</label>
                        <select id="patient_id" name="patient_id" required>
                            @foreach (\App\Support\Registry::options('patients') as $key => $label)
                                <option value="{{ $key }}" @selected((string) old('patient_id', $record->patient_id) === (string) $key)>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="doctor_id">ডাক্তার *</label>
                        <select id="doctor_id" name="doctor_id" required>
                            @foreach (\App\Support\Registry::options('doctors') as $key => $label)
                                <option value="{{ $key }}" @selected((string) old('doctor_id', $record->doctor_id) === (string) $key)>{{ $label }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="reference_id">রেফারেন্স</label>
                        <select id="reference_id" name="reference_id">

                            @foreach (\App\Support\Registry::options('references') as $key => $label)
                                <option value="{{ $key }}" @selected((string) old('reference_id', $record->reference_id) === (string) $key)>{{ $label }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="appointment_at">তারিখ ও সময় *</label>
                        <input id="appointment_at" name="appointment_at" type="datetime-local"
                            value="{{ old('appointment_at', $record->appointment_at ? \Carbon\Carbon::parse($record->appointment_at)->format('Y-m-d\TH:i') : now()->format('Y-m-d\TH:i')) }}"
                            required>
                    </div>
                    <div>
                        <label for="serial_no">সিরিয়াল নম্বর *</label>
                        <input id="serial_no" name="serial_no" type="number" min="1" step="1"
                            value="{{ old('serial_no', $record->serial_no) }}" required>
                    </div>
                    <div>
                        <label for="visit_type">ভিজিট *</label>
                        <select id="visit_type" name="visit_type" required>
                            @foreach (['new' => 'নতুন', 'followup' => 'ফলোআপ'] as $key => $label)
                                <option value="{{ $key }}" @selected((string) old('visit_type', $record->visit_type) === (string) $key)>{{ $label }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="fee">ভিজিট ফি *</label>
                        <input id="fee" name="fee" type="number" min="0" step="0.01"
                            value="{{ old('fee', $record->fee) }}" required>
                    </div>
                    <div>
                        <label for="status">স্ট্যাটাস *</label>
                        <select id="status" name="status" required>
                            @foreach (['waiting' => 'অপেক্ষমাণ', 'completed' => 'সম্পন্ন', 'cancelled' => 'বাতিল'] as $key => $label)
                                <option value="{{ $key }}" @selected((string) old('status', $record->status) === (string) $key)>{{ $label }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="notes">নোট</label>
                        <textarea id="notes" name="notes">{{ old('notes', $record->notes) }}</textarea>
                    </div>
                </div>
                <div class="actions">
                    <a class="btn" href="{{ route('visits.index') }}">তালিকা</a>
                    <button class="btn primary">সংরক্ষণ করুন</button>
                </div>
            </form>
        </div>
    </section>
@endsection
