@extends('layouts.app', ['title' => 'ডাক্তার'])
@section('content')
    <section class="panel">
        <div class="panelhead">
            <h2>{{ $record->exists ? 'তথ্য সম্পাদনা' : 'নতুন এন্ট্রি' }}</h2>
        </div>
        <div class="panelbody">
            <form method="post" action="{{ $record->exists ? route('doctors.update', $record) : route('doctors.store') }}">
                @csrf
                @if ($record->exists)
                    @method('PUT')
                @endif
                <div class="formgrid">
                    <div>
                        <label for="name">নাম *</label>
                        <input id="name" name="name" type="text" value="{{ old('name', $record->name) }}" required>
                    </div>
                    <div>
                        <label for="specialty">বিভাগ *</label>
                        <input id="specialty" name="specialty" type="text"
                            value="{{ old('specialty', $record->specialty) }}" required>
                    </div>
                    <div>
                        <label for="phone">মোবাইল</label>
                        <input id="phone" name="phone" type="text" value="{{ old('phone', $record->phone) }}">
                    </div>
                    <div>
                        <label for="fee">ভিজিট ফি *</label>
                        <input id="fee" name="fee" type="number" min="0" step="0.01"
                            value="{{ old('fee', $record->fee) }}" required>
                    </div>
                    <div>
                        <label for="followup_fee">ফলোআপ ফি *</label>
                        <input id="followup_fee" name="followup_fee" type="number" min="0" step="0.01"
                            value="{{ old('followup_fee', $record->followup_fee) }}" required>
                    </div>
                    <div>
                        <label for="available_days">কোন দিন বসেন</label>
                        <input id="available_days" name="available_days" type="text"
                            value="{{ old('available_days', $record->available_days) }}">
                    </div>
                    <div>
                        <label for="start_time">শুরুর সময়</label>
                        <input id="start_time" name="start_time" type="time"
                            value="{{ old('start_time', $record->start_time ? substr($record->start_time, 0, 5) : '') }}">
                    </div>
                    <div>
                        <label for="end_time">শেষ সময়</label>
                        <input id="end_time" name="end_time" type="time"
                            value="{{ old('end_time', $record->end_time ? substr($record->end_time, 0, 5) : '') }}">
                    </div>
                    <div>
                        <label for="active">সক্রিয় *</label>
                        <select id="active" name="active" required>
                            @foreach (['1' => 'হ্যাঁ', '0' => 'না'] as $key => $label)
                                <option value="{{ $key }}" @selected((string) old('active', $record->exists ? (int) $record->active : 1) === (string) $key)>{{ $label }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="actions">
                    <a class="btn" href="{{ route('doctors.index') }}">তালিকা</a>
                    <button class="btn primary">সংরক্ষণ করুন</button>
                </div>
            </form>
        </div>
    </section>
@endsection
