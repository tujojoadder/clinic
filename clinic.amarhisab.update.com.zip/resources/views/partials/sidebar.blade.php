<link rel="stylesheet" href="{{ asset('assets/css/sidebar.css') }}?v=1">
<aside id="sideBar">
    <div class="brand">
        <span class="logo">+</span>
        <div>Clinic Care<small>CLINIC MANAGEMENT</small>
        </div>
    </div>
    <nav id="sideNav">

        @foreach (\App\Support\Registry::modules() as $key => $definition)
            @if (\App\Support\Registry::can($key))
                @php
                    $link = in_array($key, ['dashboard', 'reports', 'settings', 'discharge'])
                        ? route($key)
                        : route('entities.index', $key);
                @endphp
                <a class="btn {{ ($module ?? 'dashboard') === $key ? 'primary' : '' }}" href="{{ $link }}">
                    {{-- <span class="navicon">{{ $definition['icon'] }}</span>{{ $definition['title'] }} --}}
                    <span class="navicon"><i class="{{ $definition['icon'] }}"></i></span>{{ $definition['title'] }}
                </a>
            @endif
        @endforeach
    </nav>

</aside>

{{-- সাইডবারের স্ক্রল পজিশন মনে রাখার স্ক্রিপ্ট (বাইরের ফাইল) --}}
<script src="{{ asset('assets/js/sidebar.js') }}?v=1"></script>
