<!doctype html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'ড্যাশবোর্ড' }} · {{ \App\Support\Registry::setting('clinic_name', 'Clinic Care') }}</title>
    <link rel="icon" type="image/png" href="{{ asset('assets/logo.png') }}">
    <link rel="stylesheet" href="{{ asset('assets/fa/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/app.css') }}">
</head>

<body>

    @include('partials.sidebar')
    <main>

        @include('partials.topbar')
        <div id="content">
            <div class="printhead hidden">
                <h1>{{ \App\Support\Registry::setting('clinic_name', 'Clinic Care') }}</h1>
                <p>{{ \App\Support\Registry::setting('clinic_address') }} ·
                    {{ \App\Support\Registry::setting('clinic_phone') }}</p>
                <p>{{ now()->format('Y-m-d H:i') }}</p>
            </div>
            <div class="heading">
                <div>
                    <div class="eyebrow">CLINIC CARE / {{ $module ?? 'dashboard' }}</div>
                    <h1>{{ $title ?? 'ড্যাশবোর্ড' }}</h1>
                    <p>রোগী, সেবা ও হিসাব এক জায়গায়</p>
                </div>
                @yield('heading-action')
            </div>

            @if (session('success'))
                <div class="success">{{ session('success') }}</div>
            @endif

            @if ($errors->any())
                <div class="error">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>

            @endif
            @yield('content')
            <div class="footer">
                <span>© {{ date('Y') }} Clinic Care · Soft Host IT</span>
                <span>{{ now()->format('d M Y H:i') }}</span>
            </div>
        </div>
    </main>
    <script src="{{ asset('assets/app.js') }}"></script>
</body>

</html>
