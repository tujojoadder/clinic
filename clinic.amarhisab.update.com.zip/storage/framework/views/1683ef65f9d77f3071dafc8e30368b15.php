<?php $__env->startSection('content'); ?><section class="panel">
<div class="panelhead">
<h2>রোগী নির্বাচন</h2>
</div>
<div class="panelbody">
<?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="btn" href="<?php echo e(route('entities.show',['admissions',$admission->id])); ?>"><?php echo e($admission->patient->name); ?> · ADM-<?php echo e($admission->id); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['title'=>'ডিসচার্জ','module'=>'discharge'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/discharge/index.blade.php ENDPATH**/ ?>