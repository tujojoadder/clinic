<?php $__currentLoopData = ['visits'=>'ভিজিট','admissions'=>'ভর্তি','lab_orders'=>'টেস্ট','invoices'=>'বিল']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<?php if(\App\Support\Registry::can($related)): ?>
        <section class="panel">
<div class="panelhead">
<h2><?php echo e($label); ?> ইতিহাস</h2>
</div>
<div class="panelbody">
            
<?php $__currentLoopData = \App\Support\Registry::model($related)->where('patient_id', $record->id)->latest('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="btn" href="<?php echo e(route('entities.show', [$related, $item->id])); ?>"><?php echo e($label); ?> #<?php echo e($item->id); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</section>
    
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/patients/history.blade.php ENDPATH**/ ?>