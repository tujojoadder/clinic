<?php $__env->startSection('content'); ?>
<section class="panel">
<div class="panelhead">
<h2><?php echo e($record->exists ? 'তথ্য সম্পাদনা' : 'নতুন এন্ট্রি'); ?></h2>
</div>
<div class="panelbody">
<form method="post" action="<?php echo e($record->exists ? route('entities.update', [$module, $record->id]) : route('entities.store', $module)); ?>">
            <?php echo csrf_field(); ?>
            
<?php if($record->exists): ?> <?php echo method_field('PUT'); ?> 
<?php endif; ?>
            <div class="formgrid">
                
<?php $__currentLoopData = $definition['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
<?php echo $__env->make('components.field', ['name' => $name, 'field' => $field, 'value' => $record->$name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
<?php if($module === 'admissions' && !$record->exists): ?>
                    
<?php echo $__env->make('components.field', ['name' => 'bed_id', 'field' => ['বেড', 'fk', true, 'beds'], 'value' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
<?php echo $__env->make('components.field', ['name' => 'advance', 'field' => ['অগ্রিম', 'number', false], 'value' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
<?php echo $__env->make('components.field', ['name' => 'method', 'field' => ['পদ্ধতি', 'select', true, ['cash'=>'ক্যাশ','bkash'=>'bKash','nagad'=>'Nagad','bank'=>'ব্যাংক']], 'value' => 'cash'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
<?php endif; ?>
            </div>
<div class="actions">
<a class="btn" href="<?php echo e(route('entities.index', $module)); ?>">তালিকা</a>
<button class="btn primary">সংরক্ষণ করুন</button>
</div>
</form>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => $definition['title']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/entities/form.blade.php ENDPATH**/ ?>