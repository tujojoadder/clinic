<link rel="stylesheet" href="<?php echo e(asset('assets/css/sidebar.css')); ?>?v=1">
<aside id="sideBar">
    <div class="brand">
        <span class="logo">+</span>
        <div>Clinic Care<small>CLINIC MANAGEMENT</small>
        </div>
    </div>
    <nav id="sideNav">

        <?php $__currentLoopData = \App\Support\Registry::modules(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $definition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\App\Support\Registry::can($key)): ?>
                <?php
                    $link = in_array($key, ['dashboard', 'reports', 'settings', 'discharge'])
                        ? route($key)
                        : route('entities.index', $key);
                ?>
                <a class="btn <?php echo e(($module ?? 'dashboard') === $key ? 'primary' : ''); ?>" href="<?php echo e($link); ?>">
                    
                    <span class="navicon"><i class="<?php echo e($definition['icon']); ?>"></i></span><?php echo e($definition['title']); ?>

                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

</aside>


<script src="<?php echo e(asset('assets/js/sidebar.js')); ?>?v=1"></script>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>