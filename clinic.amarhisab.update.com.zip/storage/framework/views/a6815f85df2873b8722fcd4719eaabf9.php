<?php $totals=app(\App\Services\BillingService::class)->totals($record); ?>
<div class="grid">
<section class="panel">
<div class="panelhead">
<h2>INV-<?php echo e($record->id); ?> · চার্জ</h2>
<span class="badge"><?php echo e($record->status); ?></span>
</div>
<div class="tablewrap">
<table>
<tr>
<th>বিবরণ</th>
<th>পরিমাণ</th>
<th>দর</th>
<th>মোট</th>
<th class="noprint">অ্যাকশন</th>
</tr>
<?php $__currentLoopData = $record->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
<td><?php echo e($item->description); ?></td>
<td><?php echo e($item->quantity); ?></td>
<td><?php echo e(\App\Support\Format::money($item->unit_price)); ?></td>
<td><?php echo e(\App\Support\Format::money($item->quantity*$item->unit_price)); ?></td>
<td class="noprint">
<?php if($record->status==='open' && $item->kind==='service' && \App\Support\Registry::can('invoices',true)): ?>
<form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'service_delete'])); ?>" data-confirm="চার্জ মুছবেন?"><?php echo csrf_field(); ?><input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
<button class="btn">মুছুন</button>
</form>
<a class="btn" href="<?php echo e(route('entities.show',['invoices',$record->id]).'?item_edit='.$item->id); ?>">এডিট</a>
<?php endif; ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php if($record->admission_id && $record->status==='open' && \App\Support\Registry::can('invoices',true)): ?><div class="panelbody">
<form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'sync_rent'])); ?>"><?php echo csrf_field(); ?><button class="btn">আজ পর্যন্ত বেডভাড়া হিসাব করুন</button>
</form>
</div>
<?php endif; ?>
</section>
<section class="panel">
<div class="panelhead">
<h2>বিলের সারসংক্ষেপ</h2>
</div>
<div class="panelbody">
<div class="summary">
<?php $__currentLoopData = ['subtotal'=>'মোট চার্জ','discount'=>'ছাড়','total'=>'মোট বিল','paid'=>'নিট আদায়','due'=>'বকেয়া / অতিরিক্ত অগ্রিম']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div>
<span><?php echo e($label); ?></span>
<b><?php echo e(\App\Support\Format::money($totals[$key])); ?></b>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<button class="btn noprint" data-print>প্রিন্ট</button>
<?php if($record->status==='open' && !$record->admission_id && \App\Support\Registry::can('invoices',true)): ?>
<form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'invoice_state'])); ?>" class="noprint"><?php echo csrf_field(); ?><input type="hidden" name="state" value="finalized">
<button class="btn">চূড়ান্ত করুন</button>
</form>
<?php if(auth()->user()->role==='admin'): ?><form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'invoice_state'])); ?>" class="noprint" data-confirm="বিল বাতিল?"><?php echo csrf_field(); ?><input type="hidden" name="state" value="void">
<button class="btn">বাতিল</button>
</form>
<?php endif; ?>
<?php endif; ?></div>
</section>
</div>
<?php if(\App\Support\Registry::can('invoices',true) && $record->status!=='void'): ?>
<section class="panel noprint">
<div class="panelhead">
<h2>পেমেন্ট / রিফান্ড</h2>
</div>
<div class="panelbody">
<form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'payment'])); ?>"><?php echo csrf_field(); ?><div class="formgrid">
<?php echo $__env->make('components.field',['name'=>'amount','field'=>['পরিমাণ','number',true],'value'=>null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'method','field'=>['পদ্ধতি','select',true,['cash'=>'ক্যাশ','bkash'=>'bKash','nagad'=>'Nagad','bank'=>'ব্যাংক']],'value'=>'cash'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'type','field'=>['ধরন','select',true,auth()->user()->role==='admin'?['receipt'=>'আদায়/অগ্রিম','refund'=>'রিফান্ড']:['receipt'=>'আদায়/অগ্রিম']],'value'=>'receipt'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'transaction_ref','field'=>['ট্রানজ্যাকশন রেফারেন্স','text',false],'value'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'reason','field'=>['কারণ (রিফান্ডে আবশ্যক)','text',false],'value'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="actions">
<button class="btn primary">পেমেন্ট সংরক্ষণ</button>
</div>
</form>
</div>
</section>
<?php endif; ?>
<section class="panel">
<div class="panelhead">
<h2>পেমেন্টের ইতিহাস</h2>
</div>
<div class="tablewrap">
<table>
<tr>
<th>রসিদ</th>
<th>সময়</th>
<th>ধরন</th>
<th>পদ্ধতি</th>
<th>পরিমাণ</th>
<th>অ্যাকশন</th>
</tr>
<?php $__currentLoopData = $record->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
<td>RC-<?php echo e($payment->id); ?></td>
<td><?php echo e($payment->paid_at); ?></td>
<td><?php echo e($payment->type); ?> <?php echo e($payment->voided_at?'· বাতিল':''); ?></td>
<td><?php echo e($payment->method); ?></td>
<td><?php echo e(\App\Support\Format::money($payment->amount)); ?></td>
<td class="noprint">
<?php if(!$payment->voided_at && auth()->user()->role==='admin'): ?><form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'void_payment'])); ?>" data-confirm="পেমেন্ট বাতিল করবেন?"><?php echo csrf_field(); ?><input type="hidden" name="payment_id" value="<?php echo e($payment->id); ?>">
<input name="reason" required placeholder="কারণ">
<button class="btn">বাতিল</button>
</form>
<?php endif; ?>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></table>
</div>
</section>
<?php if($record->status==='open' && \App\Support\Registry::can('invoices',true)): ?>
<?php $editing=request('item_edit')?$record->items()->where('kind','service')->findOrFail(request('item_edit')):null; ?>
<section class="panel noprint">
<div class="panelhead">
<h2>সার্ভিস চার্জ যোগ / সম্পাদনা</h2>
</div>
<div class="panelbody">
<form method="post" action="<?php echo e(route('workflows.action',['invoices',$record->id,'service_save'])); ?>"><?php echo csrf_field(); ?>
<?php if($editing): ?><input type="hidden" name="item_id" value="<?php echo e($editing->id); ?>">
<?php endif; ?>
<div class="formgrid">
<?php echo $__env->make('components.field',['name'=>'description','field'=>['সেবার বিবরণ','text',true],'value'=>$editing?->description], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'quantity','field'=>['পরিমাণ','number',true],'value'=>$editing?->quantity??1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'unit_price','field'=>['দর','number',true],'value'=>$editing?->unit_price], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="actions">
<button class="btn primary">চার্জ সংরক্ষণ</button>
</div>
</form>
</div>
</section>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/billing/detail.blade.php ENDPATH**/ ?>