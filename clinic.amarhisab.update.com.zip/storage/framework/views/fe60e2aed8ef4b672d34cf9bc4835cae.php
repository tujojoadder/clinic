<header>
    <button class="mobile" id="menuToggle" aria-label="মেনু খুলুন">☰</button>
    <h1><?php echo e(\App\Support\Registry::setting('clinic_name', 'Clinic Care')); ?></h1>
    <form action="<?php echo e(route('entities.index', 'patients')); ?>" method="get">
        <input class="search" name="q" placeholder="রোগীর নাম বা মোবাইল খুঁজুন">
    </form>
    <div class="user">
        <span class="avatar">FH</span>
        <div>
            <b><?php echo e(auth()->user()->name); ?></b>
            <small><?php echo e(auth()->user()->role); ?></small>
        </div>
        <form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="btn">লগআউট</button>
        </form>
    </div>
</header>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/partials/topbar.blade.php ENDPATH**/ ?>