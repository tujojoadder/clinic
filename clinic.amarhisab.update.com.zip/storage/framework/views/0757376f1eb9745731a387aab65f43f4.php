<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard.css')); ?>?v=2">
    <?php
        $icons = ['👨‍⚕️', '🛏️', '🩺', '📅', '💰'];
        $statModules = ['patients', 'admissions', 'beds', 'visits', 'invoices'];
    ?>
    <div class="dash">

        <div class="stats">
            <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $mod = $statModules[$loop->index] ?? null;
                    $url = $mod && \App\Support\Registry::can($mod) ? route('entities.index', $mod) : null;
                ?>
                <a class="stat c<?php echo e($loop->index % 5); ?> <?php echo e($url ? '' : 'nolink'); ?>" href="<?php echo e($url ?? 'javascript:void(0)'); ?>">
                    <span class="sicon"><?php echo e($icons[$loop->index % 5]); ?></span>
                    <div class="top"><?php echo e($stat[0]); ?></div>
                    <strong><?php echo e($stat[1]); ?></strong>
                    <small><?php echo e($stat[2]); ?></small>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="quick">
            <?php $__currentLoopData = ['patients' => 'নতুন রোগী', 'visits' => 'সিরিয়াল দিন', 'admissions' => 'রোগী ভর্তি', 'lab_orders' => 'টেস্ট অর্ডার']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(\App\Support\Registry::can($key, true)): ?>
                    <a class="btn qbtn q-<?php echo e($key); ?>" href="<?php echo e(route('entities.create', $key)); ?>">＋
                        <?php echo e($label); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="grid">
            <?php if(\App\Support\Registry::can('visits')): ?>
                <section class="panel p-visits">
                    <div class="panelhead">
                        <h2>📅 আজকের সিরিয়াল</h2>
                    </div>
                    <div class="tablewrap">
                        <table>
                            <tr>
                                <th>রোগী</th>
                                <th>ডাক্তার</th>
                                <th>সময়</th>
                                <th>স্ট্যাটাস</th>
                            </tr>
                            <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($visit->patient->name); ?></td>
                                    <td><?php echo e($visit->doctor->name); ?></td>
                                    <td><?php echo e($visit->appointment_at); ?></td>
                                    <td>
                                        <span class="badge s-<?php echo e($visit->status); ?>"><?php echo e($visit->status); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </section>
            <?php endif; ?>

            <?php if(\App\Support\Registry::can('lab_orders')): ?>
                <section class="panel p-lab">
                    <div class="panelhead">
                        <h2>🧪 ল্যাব কার্যক্রম</h2>
                    </div>
                    <div class="panelbody">
                        <?php $__currentLoopData = $lab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="doctor">
                                <span class="badge s-<?php echo e($row->status); ?>"><?php echo e($row->status); ?></span>
                                <span><?php echo e($row->count); ?>টি</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>
        </div>

        <?php if(\App\Support\Registry::can('admissions')): ?>
            <section class="panel p-adm">
                <div class="panelhead">
                    <h2>🛏️ সাম্প্রতিক ভর্তি</h2>
                </div>
                <div class="panelbody">
                    <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn"
                            href="<?php echo e(route('entities.show', ['admissions', $admission->id])); ?>"><?php echo e($admission->patient->name); ?>

                            · ADM-<?php echo e($admission->id); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'ড্যাশবোর্ড', 'module' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/dashboard/index.blade.php ENDPATH**/ ?>