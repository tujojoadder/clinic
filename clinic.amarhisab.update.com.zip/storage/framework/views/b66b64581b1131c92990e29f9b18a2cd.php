<section class="panel noprint">
<div class="panelhead">
<h2>ডিসচার্জ সম্পন্ন করুন</h2>
</div>
<div class="panelbody">
<form method="post" action="<?php echo e(route('workflows.action',['admissions',$record->id,'discharge'])); ?>"><?php echo csrf_field(); ?><div class="formgrid">
<?php echo $__env->make('components.field',['name'=>'discharged_at','field'=>['ছাড়পত্রের সময়','datetime-local',true],'value'=>null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'discharge_type','field'=>['ধরন','select',true,['regular'=>'নিয়মিত','transfer'=>'স্থানান্তর','own_risk'=>'নিজ দায়িত্বে']],'value'=>'regular'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'treatment_summary','field'=>['চিকিৎসার সারসংক্ষেপ','textarea',true],'value'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'followup_notes','field'=>['পরবর্তী নির্দেশনা','textarea',false],'value'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->user()->role==='admin'): ?><div>
<label>
<input class="switch" type="checkbox" name="allow_due" value="1"> বকেয়াসহ অনুমোদন</label>
</div>
<?php endif; ?>
</div>
<div class="actions">
<button class="btn primary">ডিসচার্জ করুন</button>
</div>
</form>
</div>
</section>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/discharge/form.blade.php ENDPATH**/ ?>