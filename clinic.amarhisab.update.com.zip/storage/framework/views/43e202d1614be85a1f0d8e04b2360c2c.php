<section class="panel">
<div class="panelhead">
<h2>বেডের ইতিহাস</h2>
<span class="badge"><?php echo e($record->status); ?></span>
</div>
<div class="tablewrap">
<table>
<tr>
<th>বেড</th>
<th>শুরু</th>
<th>শেষ</th>
<th>দৈনিক ভাড়া</th>
</tr>
<?php $__currentLoopData = $record->stays()->with('bed')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
<td><?php echo e($stay->bed->name); ?></td>
<td><?php echo e($stay->started_at); ?></td>
<td><?php echo e($stay->ended_at ?? 'চলমান'); ?></td>
<td><?php echo e(\App\Support\Format::money($stay->daily_rate)); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</section>
<?php if(\App\Support\Registry::can('invoices')): ?><a class="btn primary" href="<?php echo e(route('entities.show',['invoices',$record->invoice->id])); ?>">ভর্তি বিল</a>
<?php endif; ?>
<?php if($record->status === 'admitted' && \App\Support\Registry::can('admissions',true)): ?>
<section class="panel noprint">
<div class="panelhead">
<h2>বেড পরিবর্তন</h2>
</div>
<div class="panelbody">
<form method="post" action="<?php echo e(route('workflows.action',['admissions',$record->id,'transfer'])); ?>"><?php echo csrf_field(); ?><div class="formgrid">
<?php echo $__env->make('components.field',['name'=>'bed_id','field'=>['নতুন বেড','fk',true,'beds'],'value'=>null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.field',['name'=>'at','field'=>['পরিবর্তনের সময়','datetime-local',true],'value'=>null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="actions">
<button class="btn primary">পরিবর্তন</button>
</div>
</form>
</div>
</section>
<form method="post" action="<?php echo e(route('workflows.action',['admissions',$record->id,'cancel_admission'])); ?>" data-confirm="ভর্তি বাতিল করবেন?"><?php echo csrf_field(); ?><button class="btn">ভুল ভর্তি বাতিল</button>
</form>
<?php endif; ?>
<?php if($record->status === 'admitted' && \App\Support\Registry::can('discharge',true)): ?> 
<?php echo $__env->make('discharge.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<?php if($record->status === 'discharged'): ?>
<section class="panel">
<div class="panelhead">
<h2>ডিসচার্জ সামারি</h2>
<button class="btn noprint" data-print>প্রিন্ট</button>
</div>
<div class="panelbody">
<p>ছাড়পত্র: <?php echo e($record->discharged_at); ?></p>
<h2>চিকিৎসার সারসংক্ষেপ</h2>
<p><?php echo e($record->treatment_summary); ?></p>
<h2>পরবর্তী নির্দেশনা</h2>
<p><?php echo e($record->followup_notes); ?></p>
</div>
</section>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/admissions/detail.blade.php ENDPATH**/ ?>