<?php $__env->startSection('content'); ?>
<section class="panel">
<div class="panelhead">
<h2>ক্লিনিকের তথ্য</h2>
</div>
<div class="panelbody">
<form method="post" action="<?php echo e(route('settings.update')); ?>"><?php echo csrf_field(); ?><div class="formgrid">
<?php $__currentLoopData = ['clinic_name'=>'ক্লিনিকের নাম','clinic_address'=>'ঠিকানা','clinic_phone'=>'ফোন']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('components.field',['name'=>$name,'field'=>[$label,'text',false],'value'=>\App\Support\Registry::setting($name)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
<div class="actions">
<button class="btn primary">সংরক্ষণ</button>
</div>
</form>
</div>
</section>
<div class="quick">
<a class="btn" href="<?php echo e(route('entities.index','users')); ?>">ইউজার</a>
<a class="btn" href="<?php echo e(route('entities.index','tests')); ?>">টেস্ট ও মূল্য</a>
<a class="btn" href="<?php echo e(route('entities.index','test_parameters')); ?>">রিপোর্ট টেমপ্লেট</a>
</div>
<section class="panel">
<div class="panelhead">
<h2>অডিট লগ · সর্বশেষ ১০০</h2>
</div>
<div class="tablewrap">
<table>
<tr>
<th>সময়</th>
<th>ইউজার</th>
<th>কাজ</th>
<th>রেকর্ড</th>
</tr>
<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
<td><?php echo e($log->created_at); ?></td>
<td><?php echo e(\App\Models\User::find($log->user_id)?->name); ?></td>
<td><?php echo e($log->action); ?></td>
<td><?php echo e($log->entity); ?> #<?php echo e($log->entity_id); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></table>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['title'=>'সেটিংস ও অডিট লগ','module'=>'settings'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/settings/index.blade.php ENDPATH**/ ?>