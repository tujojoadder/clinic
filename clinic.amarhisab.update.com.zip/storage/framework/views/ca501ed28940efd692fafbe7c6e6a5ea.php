<?php
    $type = $field[1];
    $value = $type === 'password' ? '' : old($name, $value ?? null);
    if ($type === 'datetime-local') $value = $value ? \Carbon\Carbon::parse($value)->format('Y-m-d\TH:i') : now()->format('Y-m-d\TH:i');
    if ($type === 'date' && !$value && $name !== 'birth_date') $value = now()->format('Y-m-d');
    if ($type === 'time' && $value) $value = substr($value, 0, 5);
?>
<div>
<label for="<?php echo e($name); ?>"><?php echo e($field[0]); ?><?php echo e($field[2] ? ' *' : ''); ?></label>
    
<?php if(in_array($type, ['select', 'fk'])): ?>
        <?php $options = $type === 'select' ? $field[3] : \App\Support\Registry::options($field[3]); ?>
        <select id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" <?php if($field[2]): echo 'required'; endif; ?>>
            
<?php if(!$field[2]): ?><option value="">—</option>
<?php endif; ?>
            
<?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($key); ?>" <?php if((string)$value === (string)$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php elseif($type === 'textarea'): ?>
        <textarea id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" <?php if($field[2]): echo 'required'; endif; ?>><?php echo e($value); ?></textarea>
    <?php else: ?>
        <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" type="<?php echo e($type); ?>" value="<?php echo e($value); ?>" <?php if($field[2]): echo 'required'; endif; ?> 
<?php if($type === 'number'): ?> min="0" step="0.01" 
<?php endif; ?>>
    
<?php endif; ?>
</div>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/components/field.blade.php ENDPATH**/ ?>