<?php $__env->startSection('heading-action'); ?>
<?php if(\App\Support\Registry::can('beds',true)): ?><a class="btn primary" href="<?php echo e(route('entities.create','beds')); ?>">+ বেড যোগ</a>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="beds">
<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $stay=$bed->stays()->whereNull('ended_at')->with('admission.patient')->first(); ?>
<article class="bed <?php echo e($stay ? 'occupied' : ($bed->state==='cleaning' ? 'clean' : '')); ?>">
<div class="bedicon">▤</div>
<span class="badge"><?php echo e($stay?'দখল':$bed->state); ?></span>
<h2><?php echo e($bed->name); ?></h2>
<p><?php echo e($bed->ward); ?></p>
<p><?php echo e($stay?->admission?->patient?->name); ?></p>
<p><?php echo e(\App\Support\Format::money($bed->daily_rate)); ?> / ২৪ ঘণ্টা</p>
<div class="actions">
<a class="btn" href="<?php echo e(route('entities.show',['beds',$bed->id])); ?>">বিস্তারিত</a>
<?php if($stay && \App\Support\Registry::can('admissions')): ?><a class="btn" href="<?php echo e(route('entities.show',['admissions',$stay->admission_id])); ?>">ভর্তি</a>
<?php endif; ?></div>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<p class="hint">বেডভাড়া: শুরু হওয়া প্রতি ২৪ ঘণ্টা এক দিন; প্রতিটি bed stay আলাদা।</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['title'=>$definition['title']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/beds/index.blade.php ENDPATH**/ ?>