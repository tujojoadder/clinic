<?php $__env->startSection('content'); ?>
<section class="panel">
<div class="panelhead">
<h2><?php echo e($definition['title']); ?> · #<?php echo e($record->id); ?></h2>
</div>
<div class="panelbody">
<div class="detailgrid">
        
<?php $__currentLoopData = $definition['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
<?php if($name !== 'password'): ?><div>
<label><?php echo e($field[0]); ?></label>
<strong><?php echo e(\App\Support\Format::value($record->$name, $field)); ?></strong>
</div>
<?php endif; ?>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<div class="actions noprint">
<a class="btn" href="<?php echo e(route('entities.index', $module)); ?>">তালিকা</a>
        
<?php if(\App\Support\Registry::can($module, true)): ?>
            
<?php if($module !== 'lab_orders'): ?><a class="btn" href="<?php echo e(route('entities.edit', [$module, $record->id])); ?>">সম্পাদনা</a>
<?php endif; ?>
            
<?php if(!in_array($module, ['admissions','visits','lab_orders','invoices'])): ?>
                <form method="post" action="<?php echo e(route('entities.destroy', [$module, $record->id])); ?>" data-confirm="রেকর্ড মুছবেন?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn danger">ডিলেট</button>
</form>
            
<?php endif; ?>
        
<?php endif; ?>
    </div>
</div>
</section>
<?php if($module === 'patients'): ?> 
<?php echo $__env->make('patients.history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<?php if($module === 'visits'): ?> 
<?php echo $__env->make('visits.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<?php if($module === 'admissions'): ?> 
<?php echo $__env->make('admissions.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<?php if($module === 'invoices'): ?> 
<?php echo $__env->make('billing.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<?php if($module === 'lab_orders'): ?> 
<?php echo $__env->make('lab.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => $definition['title'].' · #'.$record->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/entities/show.blade.php ENDPATH**/ ?>