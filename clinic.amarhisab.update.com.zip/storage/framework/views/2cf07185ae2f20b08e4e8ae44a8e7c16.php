<?php $__env->startSection('heading-action'); ?>
    <?php if(\App\Support\Registry::can($module, true)): ?>
        <a class="btn primary" href="<?php echo e(route('entities.create', $module)); ?>">
            + নতুন এন্ট্রি</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="panel list">
        <div class="filters">
            <form method="get">
                <div class="sbox <?php echo e(request()->filled('q') ? 'has' : ''); ?>">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input name="q" value="<?php echo e(request('q')); ?>" placeholder="তথ্য দিয়ে খুঁজুন"
                        oninput="this.parentNode.classList.toggle('has', this.value !== '')">
                    <button type="button" class="sclear" title="মুছুন"
                        onclick="var f=this.form;f.q.value='';<?php if(request()->filled('q')): ?> f.submit();<?php else: ?> this.parentNode.classList.remove('has');f.q.focus(); <?php endif; ?>"><i
                            class="fa-solid fa-xmark"></i></button>
                </div>
                <button class="btn"><i class="fa-solid fa-magnifying-glass"></i> খুঁজুন</button>
            </form>
        </div>
        <?php $columns = array_slice(array_filter($definition['fields'], fn($key) => $key !== 'password', ARRAY_FILTER_USE_KEY), 0, 5); ?>
        <div class="tablewrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($field[0]); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>
                            অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>#<?php echo e($record->id); ?></td>

                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e(\Illuminate\Support\Str::limit(\App\Support\Format::value($record->$key, $field), 45)); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>

                                <?php if($record->status): ?>
                                    <span class="badge s-<?php echo e($record->status); ?>"><?php echo e($record->status); ?></span>
                                <?php endif; ?>
                                <a class="btn abtn view" href="<?php echo e(route('entities.show', [$module, $record->id])); ?>"><i
                                        class="fa-solid fa-eye"></i> বিস্তারিত</a>

                                <?php if(\App\Support\Registry::can($module, true) && $module !== 'lab_orders'): ?>
                                    <a class="btn abtn edit" href="<?php echo e(route('entities.edit', [$module, $record->id])); ?>"><i
                                            class="fa-solid fa-pen-to-square"></i> এডিট</a>
                                <?php endif; ?>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
                            <td colspan="8">কোনো তথ্য নেই। নতুন এন্ট্রি করুন।</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pagination">
            <span>মোট <?php echo e($records->total()); ?> রেকর্ড</span>
            <?php if($records->previousPageUrl()): ?>
                <a class="btn" href="<?php echo e($records->previousPageUrl()); ?>">← আগের</a>
            <?php endif; ?>
            <?php if($records->nextPageUrl()): ?>
                <a class="btn" href="<?php echo e($records->nextPageUrl()); ?>">পরের →</a>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => $definition['title']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/entities/index.blade.php ENDPATH**/ ?>