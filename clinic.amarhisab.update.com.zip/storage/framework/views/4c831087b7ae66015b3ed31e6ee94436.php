<?php if(\App\Support\Registry::can('visits', true)): ?>
<form method="post" action="<?php echo e(route('workflows.action', ['visits',$record->id,'visit_complete'])); ?>" class="noprint"><?php echo csrf_field(); ?><button class="btn primary">ভিজিট সম্পন্ন</button>
</form>
<?php endif; ?>
<?php if($record->invoice && \App\Support\Registry::can('invoices')): ?><a class="btn" href="<?php echo e(route('entities.show',['invoices',$record->invoice->id])); ?>">ভিজিট বিল</a>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/visits/actions.blade.php ENDPATH**/ ?>