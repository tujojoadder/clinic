<!doctype html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'ড্যাশবোর্ড'); ?> · <?php echo e(\App\Support\Registry::setting('clinic_name', 'Clinic Care')); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fa/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/app.css')); ?>">
</head>

<body>

    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>

        <?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="content">
            <div class="printhead hidden">
                <h1><?php echo e(\App\Support\Registry::setting('clinic_name', 'Clinic Care')); ?></h1>
                <p><?php echo e(\App\Support\Registry::setting('clinic_address')); ?> ·
                    <?php echo e(\App\Support\Registry::setting('clinic_phone')); ?></p>
                <p><?php echo e(now()->format('Y-m-d H:i')); ?></p>
            </div>
            <div class="heading">
                <div>
                    <div class="eyebrow">CLINIC CARE / <?php echo e($module ?? 'dashboard'); ?></div>
                    <h1><?php echo e($title ?? 'ড্যাশবোর্ড'); ?></h1>
                    <p>রোগী, সেবা ও হিসাব এক জায়গায়</p>
                </div>
                <?php echo $__env->yieldContent('heading-action'); ?>
            </div>

            <?php if(session('success')): ?>
                <div class="success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="error">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
            <div class="footer">
                <span>© <?php echo e(date('Y')); ?> Clinic Care · Soft Host IT</span>
                <span><?php echo e(now()->format('d M Y H:i')); ?></span>
            </div>
        </div>
    </main>
    <script src="<?php echo e(asset('assets/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH /var/www/vhosts/amarhisab.com/clinic.amarhisab.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>