<?php

namespace App\Http\Controllers;

use App\Http\Requests\PatientRequest;
use App\Models\Patient;
use App\Support\{Audit, Registry};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        Registry::authorize('patients');
        $query = Patient::query();
        if ($request->filled('q')) {
            $search = mb_substr((string) $request->q, 0, 150);
            $query->where(function ($query) use ($search) {
                foreach (['name', 'birth_date', 'age_years', 'gender', 'phone', 'address', 'emergency_contact'] as $column) {
                    $query->orWhere($column, 'like', '%' . $search . '%');
                }
            });
        }
        $records = $query->latest('id')->paginate(25)->withQueryString();

        return view('patients.index', ['module' => 'patients', 'records' => $records]);
    }

    public function create()
    {
        Registry::authorize('patients', true);

        return view('patients.form', ['module' => 'patients', 'record' => new Patient]);
    }

    public function store(PatientRequest $request)
    {
        $patient = DB::transaction(function () use ($request) {
            $patient = Patient::create($request->validated());
            Audit::record('create', $patient->getTable(), $patient->id, ['before' => [], 'after' => $patient->toArray()]);

            return $patient;
        });

        return redirect()->route('patients.show', $patient)->with('success', 'তথ্য সংরক্ষণ হয়েছে।');
    }

    public function show(Patient $patient)
    {
        Registry::authorize('patients');

        return view('patients.show', ['module' => 'patients', 'record' => $patient]);
    }

    public function edit(Patient $patient)
    {
        Registry::authorize('patients', true);

        return view('patients.form', ['module' => 'patients', 'record' => $patient]);
    }

    public function update(PatientRequest $request, Patient $patient)
    {
        DB::transaction(function () use ($request, $patient) {
            $patient = Patient::lockForUpdate()->findOrFail($patient->id);
            $before = $patient->toArray();
            $patient->fill($request->validated())->save();
            Audit::record('update', $patient->getTable(), $patient->id, ['before' => $before, 'after' => $patient->toArray()]);
        });

        return redirect()->route('patients.show', $patient)->with('success', 'তথ্য আপডেট হয়েছে।');
    }

    public function destroy(Patient $patient)
    {
        Registry::authorize('patients', true);
        DB::transaction(function () use ($patient) {
            $id = $patient->id;
            $table = $patient->getTable();
            $snapshot = $patient->toArray();
            $patient->delete();
            Audit::record('delete', $table, $id, $snapshot);
        });

        return redirect()->route('patients.index')->with('success', 'রেকর্ড মুছে ফেলা হয়েছে।');
    }
}
