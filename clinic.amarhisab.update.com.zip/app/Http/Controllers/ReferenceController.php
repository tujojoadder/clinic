<?php

namespace App\Http\Controllers;

use App\Http\Requests\ReferenceRequest;
use App\Models\ReferencePerson;
use App\Support\{Audit, Registry};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReferenceController extends Controller
{
    public function index(Request $request)
    {
        Registry::authorize('references');
        $query = ReferencePerson::query();
        if ($request->filled('q')) {
            $search = mb_substr((string) $request->q, 0, 150);
            $query->where(function ($query) use ($search) {
                foreach (['name', 'phone', 'commission_percent', 'joining_date'] as $column) {
                    $query->orWhere($column, 'like', '%' . $search . '%');
                }
            });
        }
        $records = $query->latest('id')->paginate(25)->withQueryString();

        return view('references.index', ['module' => 'references', 'records' => $records]);
    }

    public function create()
    {
        Registry::authorize('references', true);

        return view('references.form', ['module' => 'references', 'record' => new ReferencePerson]);
    }

    public function store(ReferenceRequest $request)
    {
        $reference = DB::transaction(function () use ($request) {
            $reference = ReferencePerson::create($request->validated());
            Audit::record('create', $reference->getTable(), $reference->id, ['before' => [], 'after' => $reference->toArray()]);

            return $reference;
        });

        return redirect()->route('references.show', $reference)->with('success', 'তথ্য সংরক্ষণ হয়েছে।');
    }

    public function show(ReferencePerson $reference)
    {
        Registry::authorize('references');

        return view('references.show', ['module' => 'references', 'record' => $reference]);
    }

    public function edit(ReferencePerson $reference)
    {
        Registry::authorize('references', true);

        return view('references.form', ['module' => 'references', 'record' => $reference]);
    }

    public function update(ReferenceRequest $request, ReferencePerson $reference)
    {
        DB::transaction(function () use ($request, $reference) {
            $reference = ReferencePerson::lockForUpdate()->findOrFail($reference->id);
            $before = $reference->toArray();
            $reference->fill($request->validated())->save();
            Audit::record('update', $reference->getTable(), $reference->id, ['before' => $before, 'after' => $reference->toArray()]);
        });

        return redirect()->route('references.show', $reference)->with('success', 'তথ্য আপডেট হয়েছে।');
    }

    public function destroy(ReferencePerson $reference)
    {
        Registry::authorize('references', true);
        DB::transaction(function () use ($reference) {
            $id = $reference->id;
            $table = $reference->getTable();
            $snapshot = $reference->toArray();
            $reference->delete();
            Audit::record('delete', $table, $id, $snapshot);
        });

        return redirect()->route('references.index')->with('success', 'রেকর্ড মুছে ফেলা হয়েছে।');
    }
}
