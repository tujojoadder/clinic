<?php

namespace App\Http\Controllers;

use App\Http\Requests\DoctorRequest;
use App\Models\Doctor;
use App\Support\{Audit, Registry};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DoctorController extends Controller
{
    public function index(Request $request)
    {
        Registry::authorize('doctors');
        $query = Doctor::query();
        if ($request->filled('q')) {
            $search = mb_substr((string) $request->q, 0, 150);
            $query->where(function ($query) use ($search) {
                foreach (['name', 'specialty', 'phone', 'fee', 'followup_fee', 'available_days', 'start_time', 'end_time', 'active'] as $column) {
                    $query->orWhere($column, 'like', '%' . $search . '%');
                }
            });
        }
        $records = $query->latest('id')->paginate(25)->withQueryString();

        return view('doctors.index', ['module' => 'doctors', 'records' => $records]);
    }

    public function create()
    {
        Registry::authorize('doctors', true);

        return view('doctors.form', ['module' => 'doctors', 'record' => new Doctor]);
    }

    public function store(DoctorRequest $request)
    {
        $doctor = DB::transaction(function () use ($request) {
            $doctor = Doctor::create($request->validated());
            Audit::record('create', $doctor->getTable(), $doctor->id, ['before' => [], 'after' => $doctor->toArray()]);

            return $doctor;
        });

        return redirect()->route('doctors.show', $doctor)->with('success', 'তথ্য সংরক্ষণ হয়েছে।');
    }

    public function show(Doctor $doctor)
    {
        Registry::authorize('doctors');

        return view('doctors.show', ['module' => 'doctors', 'record' => $doctor]);
    }

    public function edit(Doctor $doctor)
    {
        Registry::authorize('doctors', true);

        return view('doctors.form', ['module' => 'doctors', 'record' => $doctor]);
    }

    public function update(DoctorRequest $request, Doctor $doctor)
    {
        DB::transaction(function () use ($request, $doctor) {
            $doctor = Doctor::lockForUpdate()->findOrFail($doctor->id);
            $before = $doctor->toArray();
            $doctor->fill($request->validated())->save();
            Audit::record('update', $doctor->getTable(), $doctor->id, ['before' => $before, 'after' => $doctor->toArray()]);
        });

        return redirect()->route('doctors.show', $doctor)->with('success', 'তথ্য আপডেট হয়েছে।');
    }

    public function destroy(Doctor $doctor)
    {
        Registry::authorize('doctors', true);
        DB::transaction(function () use ($doctor) {
            $id = $doctor->id;
            $table = $doctor->getTable();
            $snapshot = $doctor->toArray();
            $doctor->delete();
            Audit::record('delete', $table, $id, $snapshot);
        });

        return redirect()->route('doctors.index')->with('success', 'রেকর্ড মুছে ফেলা হয়েছে।');
    }
}
