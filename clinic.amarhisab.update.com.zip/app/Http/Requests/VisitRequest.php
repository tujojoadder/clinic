<?php

namespace App\Http\Requests;

use App\Support\Registry;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class VisitRequest extends FormRequest
{
    public function authorize(): bool
    {
        return Registry::can('visits', true);
    }

    public function rules(): array
    {
        return [
            'patient_id'     => ['required', 'integer', Rule::exists('patients', 'id')],
            'doctor_id'      => ['required', 'integer', Rule::exists('doctors', 'id')],
            'reference_id'   => ['nullable', 'integer', Rule::exists('reference_persons', 'id')],
            'appointment_at' => ['required', 'date'],
            'serial_no'      => ['required', 'integer', 'min:1'],
            'visit_type'     => ['required', Rule::in(['new', 'followup'])],
            'fee'            => ['required', 'numeric', 'min:0'],
            'status'         => ['required', Rule::in(['waiting', 'completed', 'cancelled'])],
            'notes'          => ['nullable', 'string', 'max:10000'],
        ];
    }

    public function attributes(): array
    {
        return [
            'patient_id'     => 'রোগী',
            'doctor_id'      => 'ডাক্তার',
            'reference_id'   => 'রেফারেন্স',
            'appointment_at' => 'তারিখ ও সময়',
            'serial_no'      => 'সিরিয়াল নম্বর',
            'visit_type'     => 'ভিজিট',
            'fee'            => 'ভিজিট ফি',
            'status'         => 'স্ট্যাটাস',
            'notes'          => 'নোট',
        ];
    }
}
