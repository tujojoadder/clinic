<?php

namespace App\Http\Requests;

use App\Support\Registry;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class DoctorRequest extends FormRequest
{
    public function authorize(): bool
    {
        return Registry::can('doctors', true);
    }

    public function rules(): array
    {
        return [
            'name'           => ['required', 'string', 'max:150'],
            'specialty'      => ['required', 'string', 'max:150'],
            'phone'          => ['nullable', 'string', 'max:150'],
            'fee'            => ['required', 'numeric', 'min:0'],
            'followup_fee'   => ['required', 'numeric', 'min:0'],
            'available_days' => ['nullable', 'string', 'max:150'],
            'start_time'     => ['nullable', 'date_format:H:i'],
            'end_time'       => ['nullable', 'date_format:H:i'],
            'active'         => ['required', Rule::in(['1', '0'])],
        ];
    }

    public function attributes(): array
    {
        return [
            'name'           => 'নাম',
            'specialty'      => 'বিভাগ',
            'phone'          => 'মোবাইল',
            'fee'            => 'ভিজিট ফি',
            'followup_fee'   => 'ফলোআপ ফি',
            'available_days' => 'কোন দিন বসেন',
            'start_time'     => 'শুরুর সময়',
            'end_time'       => 'শেষ সময়',
            'active'         => 'সক্রিয়',
        ];
    }
}
