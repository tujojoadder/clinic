<?php

namespace App\Http\Requests;

use App\Support\Registry;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class LabOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return Registry::can('lab_orders', true);
    }

    public function rules(): array
    {
        return [
            'patient_id'   => ['required', 'integer', Rule::exists('patients', 'id')],
            'admission_id' => ['nullable', 'integer', Rule::exists('admissions', 'id')],
            'test_id'      => ['required', 'integer', Rule::exists('tests', 'id')],
            'ordered_at'   => ['required', 'date'],
        ];
    }

    public function attributes(): array
    {
        return [
            'patient_id'   => 'রোগী',
            'admission_id' => 'ভর্তি নম্বর',
            'test_id'      => 'টেস্ট',
            'ordered_at'   => 'অর্ডারের সময়',
        ];
    }
}
