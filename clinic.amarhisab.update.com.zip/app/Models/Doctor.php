<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
    protected $table = 'doctors';
    public $timestamps = false;
    protected $fillable = [
        'name',
        'specialty',
        'phone',
        'fee',
        'followup_fee',
        'available_days',
        'start_time',
        'end_time',
        'active',
        'created_at',
    ];
    protected $casts = [
        'fee' => 'decimal:2',
        'followup_fee' => 'decimal:2',
        'active' => 'boolean',
    ];

    public function visits()
    {
        return $this->hasMany(Visit::class, 'doctor_id');
    }

    public function admissions()
    {
        return $this->hasMany(Admission::class, 'doctor_id');
    }
}
