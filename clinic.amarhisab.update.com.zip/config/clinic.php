<?php

return [
    'modules' => [
        'dashboard' => [
            'title' => 'ড্যাশবোর্ড',
            'icon' => 'fa-solid fa-gauge',
            'read' => [
                'reception',
                'doctor',
                'nurse',
                'lab',
                'cashier',
            ],
            'write' => [],
        ],
        'patients' => [
            'title' => 'রোগী',
            'icon' => 'fa-solid fa-user-injured',
            'table' => 'patients',
            'read' => [
                'reception',
                'doctor',
                'nurse',
                'lab',
                'cashier',
            ],
            'write' => [
                'reception',
            ],
            'fields' => [
                'name' => [
                    'রোগীর নাম',
                    'text',
                    true,
                ],
                'birth_date' => [
                    'জন্মতারিখ',
                    'date',
                    false,
                ],
                'age_years' => [
                    'বয়স (জন্মতারিখ না থাকলে)',
                    'number',
                    false,
                ],
                'gender' => [
                    'লিঙ্গ',
                    'select',
                    true,
                    [
                        'female' => 'মহিলা',
                        'male' => 'পুরুষ',
                        'other' => 'অন্যান্য',
                    ],
                ],
                'phone' => [
                    'মোবাইল',
                    'text',
                    true,
                ],
                'address' => [
                    'ঠিকানা',
                    'textarea',
                    false,
                ],
                'emergency_contact' => [
                    'জরুরি যোগাযোগ',
                    'text',
                    false,
                ],
            ],
            'model' => 'App\\Models\\Patient',
        ],
        'doctors' => [
            'title' => 'ডাক্তার',
            'icon' => 'fa-solid fa-user-doctor',
            'table' => 'doctors',
            'read' => [
                'reception',
                'doctor',
                'nurse',
                'cashier',
            ],
            'write' => [],
            'fields' => [
                'name' => [
                    'নাম',
                    'text',
                    true,
                ],
                'specialty' => [
                    'বিভাগ',
                    'text',
                    true,
                ],
                'phone' => [
                    'মোবাইল',
                    'text',
                    false,
                ],
                'fee' => [
                    'ভিজিট ফি',
                    'number',
                    true,
                ],
                'followup_fee' => [
                    'ফলোআপ ফি',
                    'number',
                    true,
                ],
                'available_days' => [
                    'কোন দিন বসেন',
                    'text',
                    false,
                ],
                'start_time' => [
                    'শুরুর সময়',
                    'time',
                    false,
                ],
                'end_time' => [
                    'শেষ সময়',
                    'time',
                    false,
                ],
                'active' => [
                    'সক্রিয়',
                    'select',
                    true,
                    [
                        '1' => 'হ্যাঁ',
                        '0' => 'না',
                    ],
                ],
            ],
            'model' => 'App\\Models\\Doctor',
        ],
        'references' => [
            'title' => 'রেফারেন্স',
            'icon' => 'fa-solid fa-user-tag',
            'table' => 'reference_persons',
            'read' => [
                'reception',
                'cashier',
            ],
            'write' => [
                'reception',
            ],
            'fields' => [
                'name' => [
                    'নাম',
                    'text',
                    true,
                ],
                'phone' => [
                    'মোবাইল',
                    'text',
                    true,
                ],
                'commission_percent' => [
                    'কমিশন (%)',
                    'number',
                    true,
                ],
                'joining_date' => [
                    'জয়েনিং ডেট',
                    'date',
                    false,
                ],
            ],
            'model' => 'App\\Models\\ReferencePerson',
        ],
        'visits' => [
            'title' => 'ডাক্তার ও সিরিয়াল',
            'icon' => 'fa-solid fa-calendar-check',
            'table' => 'visits',
            'read' => [
                'reception',
                'doctor',
                'cashier',
            ],
            'write' => [
                'reception',
                'doctor',
            ],
            'fields' => [
                'patient_id' => [
                    'রোগী',
                    'fk',
                    true,
                    'patients',
                ],
                'doctor_id' => [
                    'ডাক্তার',
                    'fk',
                    true,
                    'doctors',
                ],
                'appointment_at' => [
                    'তারিখ ও সময়',
                    'datetime-local',
                    true,
                ],
                'serial_no' => [
                    'সিরিয়াল নম্বর',
                    'number',
                    true,
                ],
                'visit_type' => [
                    'ভিজিট',
                    'select',
                    true,
                    [
                        'new' => 'নতুন',
                        'followup' => 'ফলোআপ',
                    ],
                ],
                'fee' => [
                    'ভিজিট ফি',
                    'number',
                    true,
                ],
                'status' => [
                    'স্ট্যাটাস',
                    'select',
                    true,
                    [
                        'waiting' => 'অপেক্ষমাণ',
                        'completed' => 'সম্পন্ন',
                        'cancelled' => 'বাতিল',
                    ],
                ],
                'notes' => [
                    'নোট',
                    'textarea',
                    false,
                ],
            ],
            'model' => 'App\\Models\\Visit',
        ],
        'admissions' => [
            'title' => 'রোগী ভর্তি',
            'icon' => 'fa-solid fa-hospital-user',
            'table' => 'admissions',
            'read' => [
                'reception',
                'doctor',
                'nurse',
                'cashier',
            ],
            'write' => [
                'reception',
            ],
            'fields' => [
                'patient_id' => [
                    'রোগী',
                    'fk',
                    true,
                    'patients',
                ],
                'doctor_id' => [
                    'ডাক্তার',
                    'fk',
                    true,
                    'doctors',
                ],
                'admitted_at' => [
                    'ভর্তির তারিখ ও সময়',
                    'datetime-local',
                    true,
                ],
                'reason' => [
                    'ভর্তির কারণ',
                    'textarea',
                    true,
                ],
            ],
            'model' => 'App\\Models\\Admission',
        ],
        'beds' => [
            'title' => 'বেড ও কেবিন',
            'icon' => 'fa-solid fa-bed',
            'table' => 'beds',
            'read' => [
                'reception',
                'doctor',
                'nurse',
            ],
            'write' => [
                'reception',
            ],
            'fields' => [
                'name' => [
                    'বেড / কেবিন নম্বর',
                    'text',
                    true,
                ],
                'ward' => [
                    'ওয়ার্ড',
                    'text',
                    true,
                ],
                'type' => [
                    'ধরন',
                    'select',
                    true,
                    [
                        'ward' => 'সাধারণ',
                        'cabin' => 'কেবিন',
                        'icu' => 'ICU',
                    ],
                ],
                'daily_rate' => [
                    'প্রতি ২৪ ঘণ্টার ভাড়া',
                    'number',
                    true,
                ],
                'state' => [
                    'অবস্থা',
                    'select',
                    true,
                    [
                        'available' => 'খালি',
                        'cleaning' => 'পরিষ্কার',
                        'inactive' => 'নিষ্ক্রিয়',
                    ],
                ],
            ],
            'model' => 'App\\Models\\Bed',
        ],
        'nursing_records' => [
            'title' => 'নার্সিং রেকর্ড',
            'icon' => 'fa-solid fa-heart-pulse',
            'table' => 'nursing_records',
            'read' => [
                'doctor',
                'nurse',
            ],
            'write' => [
                'nurse',
                'doctor',
            ],
            'fields' => [
                'admission_id' => [
                    'ভর্তি নম্বর',
                    'fk',
                    true,
                    'admissions',
                ],
                'recorded_at' => [
                    'পর্যবেক্ষণের সময়',
                    'datetime-local',
                    true,
                ],
                'blood_pressure' => [
                    'রক্তচাপ (mmHg)',
                    'text',
                    false,
                ],
                'temperature' => [
                    'তাপমাত্রা (°F)',
                    'number',
                    false,
                ],
                'pulse' => [
                    'পালস',
                    'number',
                    false,
                ],
                'notes' => [
                    'নার্সিং নোট',
                    'textarea',
                    false,
                ],
            ],
            'model' => 'App\\Models\\NursingRecord',
        ],
        'lab_orders' => [
            'title' => 'টেস্ট ও ল্যাব',
            'icon' => 'fa-solid fa-flask-vial',
            'table' => 'lab_orders',
            'read' => [
                'reception',
                'doctor',
                'lab',
                'cashier',
            ],
            'write' => [
                'reception',
                'lab',
            ],
            'fields' => [
                'patient_id' => [
                    'রোগী',
                    'fk',
                    true,
                    'patients',
                ],
                'admission_id' => [
                    'ভর্তি নম্বর (ঐচ্ছিক)',
                    'fk',
                    false,
                    'admissions',
                ],
                'test_id' => [
                    'টেস্ট',
                    'fk',
                    true,
                    'tests',
                ],
                'ordered_at' => [
                    'অর্ডারের সময়',
                    'datetime-local',
                    true,
                ],
            ],
            'model' => 'App\\Models\\LabOrder',
        ],
        'invoices' => [
            'title' => 'বিলিং ও পেমেন্ট',
            'icon' => 'fa-solid fa-file-invoice-dollar',
            'table' => 'invoices',
            'read' => [
                'reception',
                'cashier',
            ],
            'write' => [
                'reception',
                'cashier',
            ],
            'fields' => [
                'patient_id' => [
                    'রোগী',
                    'fk',
                    true,
                    'patients',
                ],
                'discount' => [
                    'ছাড়',
                    'number',
                    true,
                ],
                'notes' => [
                    'বিলের নোট',
                    'textarea',
                    false,
                ],
            ],
            'model' => 'App\\Models\\Invoice',
        ],
        'discharge' => [
            'title' => 'ডিসচার্জ',
            'icon' => 'fa-solid fa-right-from-bracket',
            'read' => [
                'reception',
                'doctor',
                'nurse',
                'cashier',
            ],
            'write' => [
                'reception',
                'doctor',
            ],
        ],
        'expenses' => [
            'title' => 'আয়-ব্যয়',
            'icon' => 'fa-solid fa-money-bill-transfer',
            'table' => 'expenses',
            'read' => [
                'cashier',
            ],
            'write' => [
                'cashier',
            ],
            'fields' => [
                'category' => [
                    'খাত',
                    'text',
                    true,
                ],
                'description' => [
                    'বিবরণ',
                    'text',
                    true,
                ],
                'amount' => [
                    'পরিমাণ',
                    'number',
                    true,
                ],
                'method' => [
                    'পদ্ধতি',
                    'select',
                    true,
                    [
                        'cash' => 'ক্যাশ',
                        'bkash' => 'bKash',
                        'nagad' => 'Nagad',
                        'bank' => 'ব্যাংক',
                    ],
                ],
                'expense_date' => [
                    'তারিখ',
                    'date',
                    true,
                ],
            ],
            'model' => 'App\\Models\\Expense',
        ],
        'doctor_ledgers' => [
            'title' => 'ডাক্তারের হিসাব',
            'icon' => 'fa-solid fa-book',
            'table' => 'doctor_ledgers',
            'read' => [
                'cashier',
            ],
            'write' => [
                'cashier',
            ],
            'fields' => [
                'doctor_id' => [
                    'ডাক্তার',
                    'fk',
                    true,
                    'doctors',
                ],
                'type' => [
                    'এন্ট্রি',
                    'select',
                    true,
                    [
                        'payable' => 'প্রাপ্য',
                        'settlement' => 'পরিশোধ',
                    ],
                ],
                'amount' => [
                    'পরিমাণ',
                    'number',
                    true,
                ],
                'entry_date' => [
                    'তারিখ',
                    'date',
                    true,
                ],
                'notes' => [
                    'বিবরণ',
                    'text',
                    true,
                ],
            ],
            'model' => 'App\\Models\\DoctorLedger',
        ],

        'reports' => [
            'title' => 'রিপোর্ট',
            'icon' => 'fa-solid fa-chart-line',
            'read' => [
                'cashier',
            ],
            'write' => [],
        ],
        'users' => [
            'title' => 'ইউজার',
            'icon' => 'fa-solid fa-users',
            'table' => 'users',
            'read' => [],
            'write' => [],
            'fields' => [
                'name' => [
                    'নাম',
                    'text',
                    true,
                ],
                'email' => [
                    'ইমেইল',
                    'email',
                    true,
                ],
                'password' => [
                    'পাসওয়ার্ড (সম্পাদনার সময় ফাঁকা রাখলে অপরিবর্তিত)',
                    'password',
                    false,
                ],
                'role' => [
                    'রোল',
                    'select',
                    true,
                    [
                        'admin' => 'অ্যাডমিন',
                        'reception' => 'রিসেপশন',
                        'doctor' => 'ডাক্তার',
                        'nurse' => 'নার্স',
                        'lab' => 'ল্যাব',
                        'cashier' => 'ক্যাশিয়ার',
                    ],
                ],
                'active' => [
                    'সক্রিয়',
                    'select',
                    true,
                    [
                        '1' => 'হ্যাঁ',
                        '0' => 'না',
                    ],
                ],
            ],
            'model' => 'App\\Models\\User',
        ],
        'settings' => [
            'title' => 'সেটিংস',
            'icon' => 'fa-solid fa-gear',
            'read' => [],
            'write' => [],
        ],
        'tests' => [
            'title' => 'টেস্ট ও মূল্য',
            'icon' => 'fa-solid fa-vials',
            'table' => 'tests',
            'read' => [
                'reception',
                'lab',
                'doctor',
                'cashier',
            ],
            'write' => [],
            'fields' => [
                'name' => [
                    'টেস্টের নাম',
                    'text',
                    true,
                ],
                'sample_type' => [
                    'নমুনা',
                    'text',
                    true,
                ],
                'price' => [
                    'মূল্য',
                    'number',
                    true,
                ],
                'turnaround_hours' => [
                    'সময় (ঘণ্টা)',
                    'number',
                    true,
                ],
                'active' => [
                    'সক্রিয়',
                    'select',
                    true,
                    [
                        '1' => 'হ্যাঁ',
                        '0' => 'না',
                    ],
                ],
            ],
            'model' => 'App\\Models\\DiagnosticTest',
        ],
        'test_parameters' => [
            'title' => 'টেস্ট রিপোর্ট টেমপ্লেট',
            'icon' => 'fa-solid fa-clipboard-list',
            'table' => 'test_parameters',
            'read' => [
                'lab',
                'doctor',
            ],
            'write' => [],
            'fields' => [
                'test_id' => [
                    'টেস্ট',
                    'fk',
                    true,
                    'tests',
                ],
                'name' => [
                    'প্যারামিটার',
                    'text',
                    true,
                ],
                'unit' => [
                    'ইউনিট',
                    'text',
                    false,
                ],
                'reference_range' => [
                    'যাচাইকৃত রেফারেন্স রেঞ্জ',
                    'text',
                    false,
                ],
                'sort_order' => [
                    'ক্রম',
                    'number',
                    true,
                ],
            ],
            'model' => 'App\\Models\\TestParameter',
        ],
    ],
    'bed_rental' => 'started_24_hours',
];
